# Discord - SelfBot is a Script for discord account bot written in Python.

### This SelfBot has a total of about 60 commands to make your life on discord easier. It has a nice and intuitive interface to make it easy to use for everyone, help and explanations for each command, a very complete help command.

## Disclaimer

|SelfBot was made for Educational purposes|
|-------------------------------------------------|
This project was created only for good purposes and personal use.
By using this SelfBot, you agree that you hold responsibility and accountability of any consequences caused by your actions.

## ( HOW TO SETUP/START )

To start the bot you have to create the key with name "Token" and have to fill the the token of you account...

## HOW TO OVERCOME ERROR ?

To overcome any error or problem or any query you can contact me on insta(just_aniket.98) or on discord(https://discord.gg/qySuQrHAKH)

### TYPE HELP ON DISCORD TO SEE FEATURES OF YOU BOT...

# ][ PROJECT FINALLY COMPLETED ON 13 ][